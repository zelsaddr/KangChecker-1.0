<?php
/* 
     =============================================        
     =      ___           ___                    =
     =     /  /\         /  /\                   =
     =    /  /:/        /  /::\                  =  
     =   /  /:/        /  /:/\:\                 =  
     =  /  /::\____   /  /:/  \:\                = 
     = /__/:/\:::::: /__/:/ \  \:\               =
     = \__\/~|:|~~~~ \  \:\  \__\/               =
     =    |  |:|      \  \:\                     =      
     =    |  |:|       \  \:\                    =     
     =    |__|:|        \  \:\                   =    
     =     \__\| A N G   \__\/ H E C K E R       =
     =============================================
     = Builder : Mazterin.Com                    =
     = CP : t.me/zelsaddr                        =
     = > TEAM : - @zelsaddr ( Developer )        =
     =          - @bzsap ( Marketer & Advisor )  =
     =          - @arsyanalfrdz ( Marketer )     =
     = Est. 2K18                                 =
     = "Change Copyright Didn't Make             =
     =                             you as Coder" =
     =============================================
     ===== EDIT SC JIKA INGIN TERJADI ERROR ======
     ======= [ PAY FOR API KEY FOR RUN. ] ========
*/
$error = "Y"; // SHOW ERROR Y/N
if($error == "Y"){
    error_reporting(E_ALL);
}else{
    error_reporting(0);
}
require(__DIR__."/kc.class.php");
$kc = new KC("n"); // y or n for enable check update
$kc->ui();
echo "[#] Select Option : "; $opt = trim(fgets(STDIN));
$kc->banner();
echo "[!] Selected : ". $kc->form($opt, 0)."\n";
$apiUrl = $kc->baseUrl.$kc->form($opt, 1);
include($kc->form($opt, 2));
?>